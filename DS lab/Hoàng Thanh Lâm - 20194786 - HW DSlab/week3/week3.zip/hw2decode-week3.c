#include<stdio.h>
#include<stdlib.h>
enum {SUCCESS, FAIL};

int main(int argc, char* argv[])
{	
	int reval;
	if( argc != 4)
	{
		printf("WRONG SYNTAX! \nCORRECT: <name> <file in> <file out> <addition offset>\n");
		return 1;
	}
	
	FILE *f1 = fopen(argv[1],"r");
	FILE *f2 = fopen(argv[2],"w+");
	int add;
	char c;
	add = atoi(argv[3]);
	if(f1 == NULL)
	{
		printf("Can not open file\n");
		reval = FAIL;
	}
	else
	{
		while((c = fgetc(f1)) != EOF)
		{
			if(c != ' ')
			{
				if( c >= 'a' && c <= 'z')
				{
					c -= add;
					if(c < 'a')
					c += 26;
				}
				else if( c >= 'A' && c <= 'Z') 
				{
					c -= add;
					if(c < 'A')
					c += 26;
				}
			}
			fputc(c, f2);			
		}
		fclose(f1);
		fclose(f2);
	}
	return reval;
}
