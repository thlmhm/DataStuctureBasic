#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 81
enum {SUCCESS, FAIL};
typedef struct {
	int no;
	long st_number;
	char name[MAX];
	char phone_number[MAX];
	int diem;
} class_list;
int main(int argc, char* argv[])
{
	int reval = SUCCESS;
	class_list a[MAX];	
	int i = 0,n;

	FILE *f1 = fopen("dssinhvien.txt", "r");
	FILE *f2 = fopen("bangdiem.txt", "w");	
		
	if( f1 == NULL )
	{
		printf("Cannot open file!\n");
		reval = FAIL;		
	}
	else
	{
		printf("%-4s%-20s%-20s%-20s\n","No", "Student_number", "First_name", "Phone_number");
		while(fscanf(f1, "%d %ld %s %s \n" , &a[i].no, &a[i].st_number, a[i].name, a[i].phone_number) != EOF)
		{
			i++;
		}
		n = i;
		for(i=0; i<n;i++)
		{
			printf("%-4d%-20ld%-20s%-20s\n", a[i].no, a[i].st_number, a[i].name, a[i].phone_number);
		}
		printf("Enter score for each student:\n");
		fprintf(f2, "%-4s%-20s%-20s%-20s%-10s\n","No", "Student_number", "First_name", "Phone_number", "Score");
		for(i=0; i<n;i++)
		{
			printf("Enter score for %s:", a[i].name);
			scanf("%d", &a[i].diem);
			//fprintf(f2, "%-4s%-20s%-20s%-20s%-10s\n","No", "Student_number", "First_name", "Phone_number", "Score");
			fprintf(f2, "%-4d%-20ld%-20s%-20s%-10d\n", a[i].no, a[i].st_number, a[i].name, a[i].phone_number, a[i].diem);
		}
		
		fclose(f1);
		fclose(f2);
	}
	return reval;
}
