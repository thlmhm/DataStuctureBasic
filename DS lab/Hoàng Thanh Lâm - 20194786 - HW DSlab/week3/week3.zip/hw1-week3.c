#include<stdio.h>
#include<string.h>
#define MAX 81
enum {SUCCESS, FAIL};
int main(int argc, char *argv[])
{
	int reval = SUCCESS;
	char s1[MAX],s2[MAX];
	int line;
	char c;
	if(argc != 2 && argc != 3)
	{
		printf("WRONG SYNTAX!\nCORRECT: <cat> <file> (-p)\n");
		return 1;
	}
	if(argc ==2)
	{
		FILE *f1 = fopen(argv[1], "r");
		
		if(f1 == NULL)
		{
			printf("Can not open file!\n");
			reval = FAIL;
		}
		else
		{
			while( (fgets(s1,MAX,f1)) != NULL )
			{
				printf("%s", s1);
			}	
		}
		fclose(f1);
	}
	if(argc == 3)
	{
		if(strcmp(argv[2] , "-p") == 0)
		{
			FILE *f1 = fopen(argv[1], "r");
		
			if(f1 == NULL)
			{
				printf("Can not open file!\n");
				reval = FAIL;
			}
			else
			{
				while( (fgets(s2,MAX,f1)) != NULL )
				{
					printf("%s", s2);
					line++;
					if(line % 28 == 0)
					{	
						do{
							printf("\nEnd of page %d", line / 28);
							printf("\nContinue to next page?(Y/N)");							
							scanf("%c",&c);
							while(getchar()!='\n');
							printf("\n");
							if(c=='N')
							return 1;
						}while(c !='Y');
					}
				}
				printf("\nEnd of page %d\n", (line /28) +1);
				fclose(f1);
			}
		}
		
		else
		{
			printf("WRONG SYNTAX!\nCORRECT: <cat> <file> (-p)\n");
			return 1;
		}
	}
	return reval;
}
