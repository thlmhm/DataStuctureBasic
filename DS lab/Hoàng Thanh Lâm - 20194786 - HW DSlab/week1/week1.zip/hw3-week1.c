#include<stdio.h>
#include<string.h>
#include<time.h>
#include<stdlib.h>

int main()
{
	char article[5][10] = {"the " , "a " , "one " , "some " , "any "};
	char noun[5][10] = {"boy ", "girl ", "dog ", "town ", "car "};
	char verb[5][10] = {"drove ", "jump ", "ran ", "walked ", "skip "};
	char preposition[5][10] = {"to ", "from ", "over ", "under ", "on "};
	srand(time(NULL));
	char final[10][100];
	char fword[10][10];
	int i,j,ran = 0;
	for(j=0; j<10;j++)
	{
		for(i=0; i<6;i++)
		{
			ran = rand()%4;
			switch(i)
			{
				case 0:				
				strcpy(fword[j], article[ran]);
				fword[j][0] = fword[j][0] - 'a' + 'A';
				strcat(final[j], fword[j]);				
				break;
				
				case 1:
				strcat(final[j], noun[ran]);
				break;
				case 2:
				strcat(final[j], verb[ran]);
				break;
				case 3:
				strcat(final[j], preposition[ran]);
				break;
				case 4:
				strcat(final[j], article[ran]);
				break;
				case 5:
				strcat(final[j], noun[ran]);
				final[j][strlen(final[j])-1] = '.';
				break;			
			}
			
		}	
	}
	for(j=0;j<10;j++)
	{
		printf("%d - %s\n",j+1,final[j]);
	}
}
