#include<stdio.h>
#include<string.h>

#define size 40
typedef struct{
	char stname[size];
	char stfname[size];
}name_n;

name_n name[size];

char *getfname(char*a)
{
	int i;
	for(i = strlen(a)-1 ; i>=0 ; i--)
	{
		if(a[i] == ' ')
		{break;}
	}
	return a + i + 1;
}

void swap(name_n *a, name_n *b)
{
	name_n c;
	c = *a;
	*a = *b;
	*b = c;
}


int main()
{
	int num = 0;
	printf("Enter the number of students:");
	scanf("%d", &num);
	while(getchar() != '\n');
	
	int i,j,check, max=0;
	for(i=0; i<num;i++)
	{
		printf("Enter the name of student %d:", i+1);
		fgets(name[i].stname,size,stdin);
		sscanf(getfname(name[i].stname) ,"%s",name[i].stfname);
	}
	
	for(i=0; i < num-1; i++)
	{
		for(j=0; j<num-1; j++)
		{
			if(strcmp(name[j].stfname, name[j+1].stfname) >0)
			swap(&name[j],&name[j+1]);
		}
	}
	for(i=0; i<num; i++)
	{
		printf("%s\n", name[i].stname);
	}
	for(i=0; i<num; i++)
	{
		check = 0;
		for(j = 0; j< num; j++)
		{
			if(strcmp(name[i].stfname, name[j].stfname) == 0)
			check++;			
		}
		if(check > max)
		max = check;
	}
	printf("Maximum number of students having the same first name :%d\n", max);	
	return 0;
}
