#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct ph{
  	char model[30];
  	int memory;
  	float scr;
  	float price;
}phone;
typedef struct node{
  	phone data;
  	struct node* next;
}node;

node* insert(node* pre){
  	node *new=(node*)malloc(1*sizeof(node));
  	if(pre!=NULL){
   		pre->next=new;}
  		new->next=NULL;
  		return new;
}

node* inserthead(node* head){
  	node* new=(node*)malloc(1*sizeof(node));
  	if(head==NULL){
    		new=insert(head);
  	}
  	new->next=head;
  	return new;
}

void readnode(node* cur){
  	if(cur==NULL){
		printf("Loi con tro.\n"); 
    		return ;
    	}
  	phone temp=cur->data;
	printf("%-30s\t%-6d\t%-8.2f\t%-8.2f\n",temp.model,temp.memory,temp.scr,temp.price);
}

void enterdata(node* cur){
  	printf("Enter model:");
  	scanf("%s",cur->data.model);
  	printf("Enter memory:");
  	scanf("%d",&cur->data.memory);
  	printf("Enter screen:");
  	scanf("%f",&cur->data.scr);
  	printf("Enter price:");
  	scanf("%f",&cur->data.price);
}

void copydata( node* cur, phone* a){
  	strcpy(cur->data.model, a->model);
  	cur->data.memory=a->memory;
  	cur->data.scr=a->scr;
  	cur->data.price=a->price;
}

int searchmodel(node* head, char* s){
  	node* temp;
  	int i=1;
  	for(temp=head;temp!=NULL;temp=temp->next)
   	if(strcmp(s, temp->data.model)==0){
      		printf("%-3d\t%-30s\t%-6d\t%-8.2f\t%-8.2f\n",i,temp->data.model,temp->data.memory,temp->data.scr,temp->data.price);
      		i++;
      	}
  	return i;
}

node* searchprice(node* head, float pr){
  	node* temp;
  	for(temp=head;temp!=NULL;temp=temp->next){
    		if(temp->data.price<=pr)
      		return temp;
      	}
  	return NULL;
}
node* insertafter(node* cur){
    	node* new=(node*)malloc(1*sizeof(node));
  	if(cur==NULL){
    		new=insert(cur);
  	}
  	else{
    		new->next=cur->next;
    		cur->next=new;
    	}
  	free(new);
  	return new;
}

node* insertbefore(node* head, node* cur){
  	node* new=(node*)malloc(1*sizeof(node));
  	node* temp;
  	if(head==NULL){
    		new=insert(head);
  	}
  	else if(head==cur){
    		new=inserthead(cur);
  	}
  	else{
    		for(temp=head; temp!=NULL;temp=temp->next){
      			if(temp->next==cur)
			break;
		}
    	temp->next=new;
    	new->next=cur;
  	}
  	free(new);
  	return new;
}
  
int main()
{
  	int i=0,ch,s,n,po;
  	phone* a;
  	node* head, *temp=NULL, *cur, *new;
  	char c, string[20];
  	FILE* p,*q,*r;
  	do{
  		printf("\n----------------------MENU--------------------\n");
  		printf("1. Import from text.\n");
  		printf("2. Import from DB.\n");
  		printf("3. Print all database.\n");
  		printf("4. Search by Model.\n");
  		printf("5. Search by price(under).\n");
  		printf("6. Export to .dat.\n");
  		printf("7. Manual insertion.\n");
  		printf("8. Exit.\n");
  		printf("---------------------------------------------------------\n");
  		printf("Enter choice:");
  	do{
    		scanf("%d",&ch);
    		if(ch<1||ch>8){
      			printf("Enter again!\n");}
  		} while(ch<1||ch>8);
  		switch(ch){
  			case 1:{
   				s=0;
    				if((p=fopen("PhoneDB.txt","r"))==NULL){
      					printf("Cannot open file PhoneDB.txt.\n");
     					return 0;}
    				while(!feof(p)){
      					if(s==0)
						cur=insert(temp);
      					else 
      						cur=inserthead(temp);
      						fscanf(p,"%s %d %f %f\n",cur->data.model,&cur->data.memory,&cur->data.scr,&cur->data.price);
      						temp=cur;
    						s++;
    				}
    				head=cur;
   				fclose(p);
    				break;
  				}
  			case 2:{
    				temp=NULL;
    				if((q=fopen("PhoneDB.dat","rb"))==NULL){
      					printf("Cannot open file PhoneDB.dat.\n");
      					return 0;}
    				s=0;
    				a=(phone*)malloc(1*sizeof(phone));
    				while(1){
      					fread(a,sizeof(phone), 1, q);
      					if(feof(q))
						break;
      					cur=insert(temp);
      					copydata(cur,a);
      					if(s==0)
						head=cur;
      						temp=cur;
      						s++;
    				}
    				free(a);
    				fclose(q);
    				break;
  				}
  			case 3:{
    				int i=1;
    				printf("%-3s\t%-30s\t%-6s\t%-10s\t%-10s\n","No","Phone Model", "Memory", "Screen","Price");
    				for(temp=head; temp!=NULL;temp=temp->next){
      					printf("%-3d",i);
    					readnode(temp);
    					i++;}
    				n=i;
    				break;}
  			case 4:{
    				int d=0;
    				printf("Enter Phone model:");
    				scanf("%s",string);
    				printf("%-3s\t%-30s\t%-6s\t%-10s\t%-10s\n","No","Phone Model", "Memory", "Screen","Price");
    				d=searchmodel(head, string);
      				if(d==0)
				printf("No resul!\n");
    				break;}
  			case 5:{
    				float pr;
    				i=1;
    				printf("Enter the price:");
    				scanf("%f",&pr);
    				cur=head;
    				printf("%-3s\t%-30s\t%-6s\t%-10s\t%-10s\n","No","Phone Model", "Memory", "Screen","Price");
    				while(1){
      					temp=searchprice(cur,pr);
      					if(temp==NULL)
						break;
      					printf("%-3d",i);
      					readnode(temp);
     					i++;
      					cur=temp->next;
    				}
      				break;}
  			case 6:{
    				if((r=fopen("PhoneDB.dat","wb"))==NULL){
      					printf("Cannot open file Phone.dat.\n");
      					return 0;}
    				phone* t=(phone*)malloc(1*sizeof(phone));
    				for(temp=head;temp!=NULL;temp=temp->next){
      					strcpy(t->model,temp->data.model);
      					t->memory=temp->data.memory;
      					t->scr=temp->data.scr;
      					t->price=temp->data.price;
      					fwrite(t, sizeof(phone), 1, r);
    				}
    				fclose(r);
    				free(t);
    				break;
  				}
    			case 7:{
      				printf("Enter the position:(1-%d):",n-1);
      				do{
      					scanf("%d",&po);
      					if(po<1||po>n-1)
					printf("Enter gain!\n");
				}while(po<1||po>n-1);
      				temp=head;
      				for(i=0;i<po-1;i++){
					temp=temp->next;
      				}
      				printf("Now you are in:");
      				readnode(temp);
      				printf("Do you want to insert Before(B) or After(A):(B/A):");
      				do{
					while(getchar()!='\n');
					scanf("%c",&c);
					if(c!='A'&&c!='B')
					printf("Enter again!(A/B):\n");}
      					while(c!='A'&&c!='B');
      					if(c=='A'){
						new=insertafter(temp);
						enterdata(new);
      					}
      					else if(c=='B'){
						new=insertbefore(head,temp);
						enterdata(new);
      					}
      				break;
    				}
      			case 8:{
				printf("Exit!\n");
				break;}
  			default:printf("Error!\n");
  }
  }while(ch!=8);
  	return 0;
}
