#include<stdio.h>
#include<stdlib.h>
#define MAX_NAME 20
#define MAX_PHONE 20
#define MAX_LEN 80
void my_fflush()
{
	char c;
	do
	{
     		c=getchar();
	}
	while(c!='\n');

}
typedef struct{
	int no;
	int ID;
	char fname[MAX_NAME];
	char phone[MAX_PHONE];
	double score;
}Student;

int count_student(FILE *fin)
{
	char buff[MAX_LEN+1];
	int num=0;
	while(!feof(fin))
	{
	fgets(buff,MAX_LEN,fin);
	num++;
	}
	return num;
}

void readfile(FILE *fin,Student *student,int count)
{
	for(int i=0;i<count;i++)
	{
		fscanf(fin,"%d %d %s %s",&student[i].no,&student[i].ID,student[i].fname,student[i].phone);
	}
	fclose(fin);
}


void insert(Student *student,int count)
{
	printf("Enter students' score:\n");
	for(int i=0;i<count-1;i++)
	{
		printf("Student %s ",student[i].fname);
		scanf("%lf",&student[i].score);
		my_fflush();
	}	
}

void writefile(FILE *fout,Student *student,int count)
{
	fprintf(fout,"%-4s%-15s%-25s%-25s%-5s\n","No","Student_ID","First_Name","Phone","Score");
	for(int i=0;i<count;i++)
	{
		fprintf(fout,"%-4d%-15d%-25s%-25s%-5.2lf\n",student[i].no,student[i].ID,student[i].fname,student[i].phone,student[i].score);
	}
}

void addstudent(Student* student,int count,int add,FILE *fout)
{
	student=(Student* )realloc(student,(count+add)*sizeof(Student));
	for(int i=count;i<count+add;i++)
	{
		printf("Insert student No %d\n",i+1);
		student[i].no=i+1;
		printf("First name: ");
		scanf("%s",student[i].fname);
		printf("ID: ");
		scanf("%d",&student[i].ID);
		my_fflush();
		printf("Phone: ");
		scanf("%s",student[i].phone);
		printf("Score: ");
		scanf("%lf",&student[i].score);
		my_fflush();
		fprintf(fout,"%-4d%-15d%-25s%-25s%-5.2lf\n",student[i].no,student[i].ID,student[i].fname,student[i].phone,student[i].score);
	}
}

int main()
{
	FILE *fin;
	FILE *fout;
	Student *Studentlist;
	int count=0;
	int add=0;
	char filename1[]="dssinhvien.txt";
	char filename2[]="transcript.txt";
	if((fin=fopen(filename1,"r"))==NULL)
	{
		printf("Can not open %s\n",filename1);
		return 0;
	}
	else if((fout=fopen(filename2,"w"))==NULL)
	{
		printf("Can not open %s\n",filename2);
		return 0;
	}
	count=count_student(fin);
	Studentlist=(Student*)malloc(count*sizeof(Student));
	if(Studentlist==NULL)
	{
		printf("Cannot allocate memory !!\n" );
		return 1;
	}
	fin=fopen(filename1,"r");
	readfile(fin,Studentlist,count);
	insert(Studentlist,count);
	writefile(fout,Studentlist,count);
	fclose(fout);
	printf("Enter the number of additional students: ");
	do{
		scanf("%d",&add);
		my_fflush();
		if(add<0)
			printf("Invalid additional students!!\nRe-enter the number of additional students:");
	}while(add<0);
	fout=fopen(filename2,"a");
	addstudent(Studentlist,count,add,fout);
	fclose(fout);
}

