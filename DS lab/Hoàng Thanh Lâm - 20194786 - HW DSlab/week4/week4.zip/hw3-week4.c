#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define MAX 80
#define max 1000
enum {SUCCESS, FAIL};
void cpychar(FILE*f1, FILE*f2){
	int i = 0;
	char c;
	while((c=fgetc(f1)) != EOF){
		fputc(c,f2);
		i++;
	}
	printf("Total %d characters\n",i);
	fclose(f1);
	fclose(f2);
}

void cpyline(FILE*f1, FILE*f2){
	int i = 0;
	char str[max];
	while( (fgets(str,max,f1)) != NULL){
		fprintf(f2,"%s", str);
		i++;
	}
	printf("Total %d lines\n", i);
	fclose(f1);
	fclose(f2);
}

void cpyblock(FILE*f1, FILE* f2){
	int maxlen;
	printf("Enter block size:");
	scanf("%d", &maxlen);
	int num;
	char buff[maxlen+1];
	while(!feof(f1)){
		num = fread(buff,sizeof(char),maxlen,f1);
		buff[num*sizeof(char)] = '\0';
		fwrite(buff,sizeof(char),num,f2);
	}
	fclose(f1);
	fclose(f2);
}

int main(int argc , char* argv[])
{
	int reval = SUCCESS;
	if(argc != 3){
		printf("Wrong syntax!\n Correct: <name><fliein><fileout>\n");
		reval = FAIL;
	}
	int choice;
	clock_t t;
	FILE *f1;
	FILE *f2;
	
		do{
			printf("------MENU------\n");
			printf("1. Copy by character.\n");
			printf("2. Copy by line.\n");
			printf("3. Copy by block.\n");
			printf("4. Exit.\n");
			printf("Enter your choice:");
			scanf("%d", &choice);
			f1 = fopen(argv[1],"r");
			f2 = fopen(argv[2],"w");
			if(f1 == NULL){	
				printf("Can not open file\n");
				return 0;
			}
			if(f2 == NULL){
				printf("Can not open file\n");
				return 0;
			}
			switch(choice){
				case 1:
					t= clock();
					cpychar(f1,f2);
					t= clock() - t;
					printf("Time copy by character:%.10lf\n", (double)t / (CLOCKS_PER_SEC));
				break;
				case 2:
					t= clock();
					cpyline(f1,f2);
					t= clock() - t;
					printf("Time copy by line:%.10lf\n", (double)t / (CLOCKS_PER_SEC));
				break;
				case 3:
				 	t= clock();
					cpyblock(f1,f2);
					t= clock() - t;
					printf("Time copy by block:%.10lf\n", (double)t / (CLOCKS_PER_SEC));
				break;
				case 4:
					printf("Goodbye\n");
				break;
				default:
					printf("Your choice must be 1-4!\n");
				break;				
			}		
		}while(choice != 4);
	
	return reval;
}
