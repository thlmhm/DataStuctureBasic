#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 100
char *subStr(char*s1, int offset, int number)
{
	int lens,i;
	lens = strlen(s1);
	char *sub;
	int j =0;
	sub = (char*)malloc((number+1)*sizeof(char));
	if(sub == NULL){
		printf("Memory allocation failed!\n");
		return NULL;
	}
		
	for(i = offset; i < lens; i++){
		sub[j] = s1[i];
		j++;
		if(i == offset + number - 1)
		{	
			break;
		}
	} 
	sub[j] = '\0';
	return sub;	
}
int main()
{
	char s[MAX];
	char *substr;
	int os,ln;
	printf("Enter the string:\n");
	fgets(s, sizeof(s), stdin);
	//while(getchar() !='\n');
	while(1){
		printf("Enter the offset index:\n");
		scanf("%d", &os);
		if(os<0)
			printf("Offset must be positive\n");
		else
			break;
	}
	while(1){
		printf("Enter the number characters:\n");
		scanf("%d", &ln);
		if(ln<0)
			printf("Number must be positive\n");
		else
			break;
		
	}
	substr = subStr(s,os,ln);
	printf("The subString is %s\n", substr);
	free(substr);
	return 0;
}
