#include<stdio.h>
#include<stdlib.h>

enum {SUCCESS, FAIL};
int main(int argc, char* argv[])
{
	int reval = SUCCESS;
	char c;
	if(argc != 3)
	{
		printf("Wrong syntax!\n CORRECT: RECT <FILE1> <FILE2> \n");
		return 1;
	}
	
	FILE *f1;
	FILE *f2;
	
	f1 = fopen(argv[1], "r");
	f2 = fopen(argv[2], "w");
	
	if( f1 == NULL )
	{
		printf("Cannot open file!\n");
		reval = FAIL;		
	}
	else if (f2 == NULL)
	{
		printf("Cannot open file!\n");
		reval = FAIL;
	}
	else
	{
		while( (c = fgetc(f1)) != EOF )
		{
			fputc(c, f2);
			putchar(c);
		}
	}
	fclose(f1);
	fclose(f2);
	return reval;
}
