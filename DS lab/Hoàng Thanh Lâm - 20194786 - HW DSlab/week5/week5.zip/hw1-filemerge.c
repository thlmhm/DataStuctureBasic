#include<stdio.h>
#include<stdlib.h>
#define MAX 81
enum{SUCCESS,FAIL};
typedef struct{
	char name[20];
	char tel[11];
	char email[25];
}phoneaddress;
int main(int argc, char* argv[])
{
	int reval = SUCCESS;
	int irc;
	int i1 = 1;
	int i2 = 1;
	phoneaddress a[MAX];
	if(argc != 4){
		printf("WRONG SYNTAX!\nCORRECT: filemerge <subfile1><subfile2><filemerge>\n");
		return 0;
	}	
	FILE *f1;
	FILE *f2;
	FILE *f3;
	int count1 = 0;
	int count2 = 0;
	if((f3 = fopen(argv[3], "w+b")) == NULL){
		printf("Can not open file %s\n", argv[1]);
		reval = FAIL;
	}
	else{
		if((f1 = fopen(argv[1], "rb")) == NULL){
			printf("Can not open file %s", argv[1]);
			reval = FAIL;
		}
		while(1){
			fread(a, sizeof(phoneaddress), 1,f1);
			count1++;
			if(feof(f1)){
				break;
			}
		}
		rewind(f1);
		do{
			fread(a, sizeof(phoneaddress), 1,f1);
			fwrite(a, sizeof(phoneaddress), 1,f3);
 			i1++;
 		}while(i1 < count1);
 		fclose(f1);
		if((f2 = fopen(argv[2], "rb")) == NULL){
			printf("Can not open file %s", argv[2]);
			reval = FAIL;
		}
		while(1){
			fread(a, sizeof(phoneaddress), 1,f2);
			count2++;
			if(feof(f2)){
				break;
			}
		}
		rewind(f2);
		do{
			fread(a, sizeof(phoneaddress), 1,f2);
			fwrite(a, sizeof(phoneaddress), 1,f3);
 			i2++;
 		}while(i2 < count2);
 		fclose(f2);
	}
	fclose(f3);
	return reval;
}
