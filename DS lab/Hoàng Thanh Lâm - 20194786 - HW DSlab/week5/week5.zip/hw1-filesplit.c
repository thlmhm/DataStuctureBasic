#include<stdio.h>
#include<stdlib.h>
#define MAX 81
enum{SUCCESS,FAIL};
typedef struct{
	char name[20];
	char tel[11];
	char email[25];
}phoneaddress;
int main(int argc, char* argv[])
{
	int reval = SUCCESS;
	int irc;
	int i = 1;
	phoneaddress a[MAX];
	if(argc != 5){
		printf("WRONG SYNTAX!\nCORRECT: filesplit <filename><number><subfile1><subfile2>\n");
		return 0;
	}	
	FILE *f1;
	FILE *f2;
	FILE *f3;
	int num;
	int count = 0;
	num = atoi(argv[2]);
	if((f1 = fopen(argv[1], "rb")) == NULL){
		printf("Can not open file %s\n", argv[1]);
		reval = FAIL;
	}
	else{
		while(1){
			fread(a, sizeof(phoneaddress), 1,f1);
			count++;
			if(feof(f1)){
				break;
			}
		}
		rewind(f1);
		if((f2 = fopen(argv[3], "w+b")) == NULL){
			printf("Can not open file %s", argv[3]);
			reval = FAIL;
		}
		do{
			fread(a, sizeof(phoneaddress), 1,f1);
			fwrite(a, sizeof(phoneaddress), 1,f2);
 			i++;
 		}while(i <= num);
 		fclose(f2);
 		if((f3 = fopen(argv[4], "w+b")) == NULL){
			printf("Can not open file %s", argv[4]);
			reval = FAIL;
		}
		do{
			fread(a, sizeof(phoneaddress), 1,f1);
			fwrite(a, sizeof(phoneaddress), 1,f2);
 			i++;
 		}while(i < count);		
 		fclose(f3);
	}
	fclose(f1);
	return reval;
}
