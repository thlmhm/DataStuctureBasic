#include<stdio.h>
enum{SUCCESS,FAIL};
#define MAX 25
typedef struct{
	char name[20];
	char tel[11];
	char email[25];
}phoneaddress;
int main(int argc, char*argv[])
{
	int reval = SUCCESS;
	int irc,i;
	phoneaddress a[MAX];
	if(argc != 2){
		printf("WRONG SYNTAX!\n CORRECT: read <filename> \n");
		return 0;
	}
	FILE *f;
 	if((f = fopen(argv[1], "rb")) == NULL){
 		printf("Can not open file!");
 		reval = FAIL;
 	}

 	irc = fread(a, sizeof(phoneaddress), MAX,f);
 	printf("%d", irc);
 	for( i = 0; i<irc ; i++){
 		printf("\n%-25s%-25s%-25s\n", a[i].name, a[i].tel, a[i].email);
 	}
 	fclose(f);
 	return reval;
}
