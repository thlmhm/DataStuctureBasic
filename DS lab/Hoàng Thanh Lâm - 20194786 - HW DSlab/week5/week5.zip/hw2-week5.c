#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 100
typedef struct smartphone
{
char name[20];
int memory;
float size;
int price;
}smartphone;


void hienthi(smartphone* smart,int count)
{
for(int i=0;i<count-1;i++)
{
	printf("%-20s%-10d%-10f%-20d\n",smart[i].name,smart[i].memory,smart[i].size,smart[i].price);
}

}
int import(FILE *fin,FILE *fout)
{
int count=0;
smartphone smart[SIZE];
while(!feof(fin))
{
fscanf(fin,"%s%d%f%d",smart[count].name,&smart[count].memory,&smart[count].size,&smart[count].price);
count++;
}
hienthi(smart,count);
fwrite(smart,sizeof(smartphone),count,fout);
fclose(fin);
fclose(fout);
return count;
}

void read_all_file(FILE *fin,int count)
{
smartphone smart[SIZE];
fread(smart,sizeof(smartphone),count,fin);
hienthi(smart,count);
fclose(fin);
}

void xoa_bo_dem()
{
char ch;
do{
ch=getchar();
}
while(ch!='\n');
}

void read_bg(FILE *fin)
{
int begin,end,count;
printf("Start: ");
scanf("%d",&begin);
xoa_bo_dem();
printf("Final:  ");
scanf("%d",&end);
count=end-begin+2;
smartphone smart[SIZE];
fseek(fin,(begin-1)*sizeof(smartphone),SEEK_SET);
fread(smart,sizeof(smartphone),count,fin);
hienthi(smart,count);
fclose(fin);
}
void search_smart(FILE *fin)
{
int check=0;
char name[50];
smartphone smart;
printf("Enter the smartphone: ");
scanf("%s",name);
fseek(fin,0,SEEK_SET);
while(!feof(fin))
{
fread(&smart,sizeof(smartphone),1,fin);
if(strcmp(smart.name,name)==0)
{
	check=1;
	printf("%-20s%-10d%-10f%-20d\n",smart.name,smart.memory,smart.size,smart.price );
}
}
if(check==0)
printf("Can not find %s",name);
}
int main()
{
char filename1[]="PhoneDB.txt";
char filename2[]="PhoneDB.dat";

FILE *fin;
FILE *fout;
int count=0;
int choice=0;
int n=0;
do
{
printf("1.Import DB\n" );
printf("2.Read file\n");
printf("3.Print Data\n");
printf("4.Search smartphone\n");
printf("5.Exit\n");
printf("You choose: ");
do{
scanf("%d",&choice);
xoa_bo_dem();
if(choice<=0||choice>5)
{
printf("Wrong choice\nYou choose" );
}
}while(choice<=0||choice>5);

switch(choice)
{
case 1:
if((fin=fopen(filename1,"r"))==NULL)
{
	printf("Can't find %s\n",filename1);
	
}
else if((fout=fopen(filename2,"wb"))==NULL)
{
	printf("Can't find %s\n",filename2);
}
else
{
	count=import(fin,fout);
}
break;
case 2:
fin=fopen("PhoneDB.dat","rb");
printf("1.Read all\n");
printf("2.Read partially\n");
printf("You choose: ");
do{
scanf("%d",&n);
if(n<=0||n>2)
xoa_bo_dem();
}while(n<=0||n>2);
if(n==1)
{
read_all_file(fin,count);
}
else if(n==2)
{
read_bg(fin);
}
break;
case 3://case 2
break;
case 4:
fin=fopen("PhoneDB.dat","rb");
search_smart(fin);
break;
case 5:
break;
}
}
while(choice!=5);

}
